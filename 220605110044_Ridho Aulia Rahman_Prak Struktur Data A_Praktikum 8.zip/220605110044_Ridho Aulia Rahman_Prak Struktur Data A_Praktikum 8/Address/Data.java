package Address;

public class Data {
    private int data;

    public Data(int data) {
        this.data = data;
    }

    public int getKey() {
        return data;
    }
}





